'use client';

import PaintCalculator from './components/PaintCalculator';

export default function Home() {
  return <PaintCalculator />;
}
